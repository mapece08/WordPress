<?php
namespace W3TC;

if ( !defined( 'W3TC' ) )
	die();

?>
<?php $this->checkbox( 'minify.html.strip.crlf', false, 'html_' ) ?> <?php Util_Ui::e_config_label( 'minify.html.strip.crlf' ) ?></label><br />
